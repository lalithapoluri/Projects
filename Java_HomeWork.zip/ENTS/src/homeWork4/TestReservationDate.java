package homeWork4;

public class TestReservationDate {

	public static void main(String[] args)

	{
		ReservationDate date1 = new ReservationDate(2013,3,2);
		ReservationDate date2 = new ReservationDate(2013,2,21);
		System.out.println("The first date is"+date1.toString());
		System.out.println("The second date is"+date2.toString());
		if(date1.checkPreviousDay(date2))System.out.println("First Date is earlier than second");
		else System.out.println("First Date is not earlier than second");
		ReservationDate.calculateDays(date1,date2);

	}

	} 

