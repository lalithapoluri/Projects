
package homeWork4;
import java.util.Scanner;
public class HotelReservationTest {

	public static void main(String[] args) {
		Scanner data=new Scanner(System.in);
		System.out.print("Please enter the customer's name:");
		String name=data.nextLine();
		System.out.print("Please enter the customer's address:");
		String address=data.nextLine();
		System.out.println("Please enter the check-in date:");
		System.out.print("Year:");
		int year=data.nextInt();
		System.out.print("Month:");
		int month=data.nextInt();
		System.out.print("Date:");
		int date=data.nextInt();
		ReservationDate aCheckInDate=new ReservationDate(year,month,date);
		HotelReservation HR1= new HotelReservation(name,address,aCheckInDate);
		System.out.println(HR1);
		System.out.println("Please enter the check-out date:");
		System.out.print("Year:");
		int year2=data.nextInt();
		System.out.print("Month:");
		int month2=data.nextInt();
		System.out.print("Date:");
		int date2=data.nextInt();
		ReservationDate aCheckOutDate=new ReservationDate(year2,month2,date2);
		HR1.checkout(aCheckOutDate);
		System.out.println(HR1);
	}

}
/*Sample Input Output
 Please enter the customer's name:sahitya maruvada
Please enter the customer's address:7704 adelphi road,apt11,hyattsville MD 20783
Please enter the check-in date:
Year:2016
Month:10
Date:11
The current reservation state:
HotelReservation object:
Name: sahitya maruvada, Address:7704 adelphi road,apt11,Hyattsville MD 20783
 Check-in Date:  October 11, 2016, check-out Date: Not known yet
Please enter the check-out date:
Year:2016
Month:11
Date:5
The number of days between the first date and the second date is: 25
The amount to be paid is 3750.0
The reservation state after checkout:
HotelReservation object:
Name: sahitya maruvada, Address:7704 adelphi road,apt11,hyattsville MD 20783
 Check-in Date:  October 11, 2016, check-out Date:  November 5, 2016
 
Please enter the customer's name:joey
Please enter the customer's address:central perk, NY
Please enter the check-in date:
Year:2021
Month:04
Date:12
The current reservation state:
HotelReservation object:
Name: joey, Address:central perk, NY
 Check-in Date:  April 12, 2021, check-out Date: Not known yet
Please enter the check-out date:
Year:2021
Month:6
Date:31
Exception in thread "main" java.lang.IllegalArgumentException: Its not a valid day in the month!
	at homework_4.ReservationDate.<init>(ReservationDate.java:47)
	at homework_4.HotelReservationTest.main(HotelReservationTest.java:29)
*/
