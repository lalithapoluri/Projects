package homeWork4;

public class HotelReservation {
private static double roomPrice=150;
private String name;
private String address;
private ReservationDate checkInDate;
private ReservationDate checkOutDate;

public HotelReservation(String custName, String custAddress,ReservationDate checkInDate){
	this.name = custName;
	this.address=custAddress;
	this.checkInDate=checkInDate;
	this.checkOutDate=checkInDate;
}
public double checkout(ReservationDate checkOutDate1){
	if(checkInDate.checkPreviousDay(checkOutDate1)){
		checkOutDate=checkOutDate1;
		int totalDays=ReservationDate.calculateDays(checkInDate, checkOutDate);
		double amountDue=totalDays*roomPrice;
		System.out.println("The amount to be paid is "+amountDue);
		return amountDue;
	}
	else
		throw new IllegalArgumentException("The Checkout date should be atleast one day later than Check -In date");
}
public String toString(){
	if(checkOutDate==checkInDate){
		
		return "The current reservation state:\n"+"HotelReservation object:\n"+"Name: "+name+", Address:"+address+"\n Check-in Date: "+checkInDate.toString()+", check-out Date: Not known";
	}
	else
		return "The reservation after checkout:\n"+"HotelReservation object:\n"+"Name: "+name+", Address:"+address+"\n Check-in Date: "+checkInDate.toString()+", check-out Date: "+checkOutDate.toString();
}
}
