package homeWork4;

public class ReservationDate // package scope
{
private static final int DEFAULT_YEAR = 1900;

private static final int DEFAULT_MONTH = 1;

private static final int DEFAULT_DAY = 1;

private static final int[] DAYS_PER_MONTH = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30,

31, 30, 31 };

private static final String[] MONTH_NAMES = { "", "January", "February", "March","April", "May", "June", "July", "August", "September", "October", "November",

"December" };

private int year;

private int month;

private int day;


public ReservationDate(int aYear, int aMonth, int aDay){
	setDate(aYear, aMonth, aDay);
} 

public ReservationDate() {
	this(DEFAULT_YEAR,DEFAULT_MONTH,DEFAULT_DAY); 
} 

public int getYear(){
	return year;
} 

public int getMonth(){
	return month;
}

public int getDay(){
	return day;
} 

public String toString(){
	return "Date object: Year: " + year + ", Month: " + MONTH_NAMES[month] +", Day: " + day + ".";
} 

public void setDate(int aYear, int aMonth, int aDay){

year = checkYear(aYear);

month = checkMonth(aMonth);

day = checkDay(aYear, aMonth, aDay);

} 
private int checkYear(int aYear){

	if(aYear >= 0)
		return aYear;
			throw new IllegalArgumentException("The year value must be positive");
} 
private int checkMonth(int aMonth){

	if( aMonth > 0 && aMonth < 13 )
		return aMonth;
			throw new IllegalArgumentException("The month must be between 1 and 12.");
}
private int checkDay(int aYear, int aMonth, int aDay){
	if(aDay > 0 && aDay <= DAYS_PER_MONTH[month])
		return aDay;

	if( aDay == 29 && aMonth == 2 &&
			(aYear % 400 == 0 || (aYear % 4 == 0 && aYear % 100 != 0) ) )
	return aDay;
		throw new IllegalArgumentException("The day value is out of range for the specified year and month.");

}

public boolean checkPreviousDay(ReservationDate next){
	if(this.year<next.year){
		return true;
	}
	else if((this.year==next.year && this.month<next.month)||(this.year==next.year && this.month==next.month && this.day<next.day)){
		return true;
	}
	else{
		return false;
	}
}

public static int calculateDays(ReservationDate firstDate,ReservationDate secondDate){
	
	int difference = firstDate.month == secondDate.month && firstDate.year == secondDate.year ? secondDate.day-firstDate.day : (DAYS_PER_MONTH[firstDate.month] - firstDate.day) + secondDate.day;
	
	if(firstDate.year > secondDate.year || (firstDate.year == secondDate.year && firstDate.month > secondDate.month) || (firstDate.year == secondDate.year && firstDate.month==secondDate.month && firstDate.day > secondDate.day))
		
    		throw new IllegalArgumentException("The first date should be earlier than the second.");
	else{
    int firstMonth = firstDate.month + 1;
    int  secondMonth = secondDate.month - 1;
    int  firstYear = firstDate.year;
    int secondYear = secondDate.year;
    
    for (; firstYear <= secondYear; firstYear++, firstMonth = 1) {
    	secondMonth = firstYear == secondYear ? (secondDate.month - 1) : 12;
        if (firstYear % 400 == 0 || (firstYear % 4 ==0 && firstYear % 100!=0)) DAYS_PER_MONTH[2] = 29;
        else DAYS_PER_MONTH[2] = 28;
        if (secondMonth == 0) {
        	secondMonth = 12;
        	secondYear = secondYear - 1;
        }
        for (; firstMonth <= secondMonth && firstYear <= secondYear; firstMonth++) difference = difference + DAYS_PER_MONTH[firstMonth];
    }	    
    System.out.println("The number of days between the first and second date is: "+difference);
    
	return difference;
	}
}

} 

