package homeWork2;

import java.util.Arrays;

public class First {

	public static void main(String[] args) {
		int numbers[]={2, -3, 5, 0, -20, 33, 52, -80, -81, 83, 2, 6, 17};
		int positiveEven[]=null;
		int positiveOdd[]=null;
		int negativeEven[]=null;
		int negativeOdd[]=null;
		int c1 = 1,c2=1,c3=1,c4=1;
		for(int i=0;i<numbers.length;i++)
		{
			if(numbers[i]<0){
				if(numbers[i]%2==0){
					negativeEven=new int[c1];
					negativeEven[c1-1]=numbers[i];
					c1++;
				}
				else{
					negativeOdd=new int[c2];
					negativeOdd[c2-1]=numbers[i];
					c2++;
				}
			}
			else{
				if(numbers[i]%2==0){
					positiveEven=new int[c3];
					positiveEven[c3-1]=numbers[i];
					c3++;
				}
				else{
					positiveOdd=new int[c4];
					positiveOdd[c4-1]=numbers[i];
					c4++;
				}
				
			}
			
		}
		
		System.out.println("Nonnegative even numbers: "+Arrays.toString(positiveEven));
		System.out.println("Negative even numbers: "+Arrays.toString(negativeEven));
		System.out.println("Nonnegative odd numbers: "+Arrays.toString(positiveOdd));
		System.out.println("Negative odd numbers: "+Arrays.toString(negativeOdd));
	}

}
