package homeWork2;

import java.util.Arrays;

public class First_Sort {
	
	public static String getNumberType(int n1){
		if(n1<0){
			if(n1%2==0) return "NE";
			else return "NO";
		}
		else{
			if(n1%2==0) return "PE";
			else return "PO";
			}
	}
	public static void printNumbers(int c1,int c2,int c3,int c4,int[] numbers){
		int positiveEven[]=new int[c3];
		int positiveOdd[]=new int[c4];
		int negativeEven[]=new int[c1];
		int negativeOdd[]=new int[c2];
		String result="";
		int p1=0,p2=0,p3=0,p4=0;
		
		for(int i=0;i<numbers.length;i++){
			result=getNumberType(numbers[i]);
			if(result.equals("NE")) 
			{
				negativeEven[p1]=numbers[i];
				p1++;
			}
			else if(result.equals("NO")) {
				negativeOdd[p2]=numbers[i];
				p2++;
			}
			else if(result.equals("PE")) {
				positiveEven[p3]=numbers[i];
				p3++;
			}
			else if(result.equals("PO")) {
				positiveOdd[p4]=numbers[i];
				p4++;
			}
		}
		System.out.println("Nonnegative even numbers: "+Arrays.toString(positiveEven));
		System.out.println("Negative even numbers: "+Arrays.toString(negativeEven));
		System.out.println("Nonnegative odd numbers: "+Arrays.toString(positiveOdd));
		System.out.println("Negative odd numbers: "+Arrays.toString(negativeOdd));
		
	}

	public static void main(String[] args) {
		
		int numbers[]={2, -3, 5, 0, -20, 33, 52, -80, -81, 83, 2, 6, 17};
		int c1=0,c2=0,c3=0,c4=0;
		String result="";
		for(int i=0;i<numbers.length;i++){
			result=getNumberType(numbers[i]);
			if(result.equals("NE")) c1++;
			else if(result.equals("NO")) c2++;
			else if(result.equals("PE")) c3++;
			else if(result.equals("PO")) c4++;
		}
		printNumbers(c1,c2,c3,c4,numbers);
	}

}
