package homeWork2;

import java.util.Scanner;

public class Fourth {

	public static void main(String[] args) {
		
		Scanner obj=new Scanner(System.in); //Declaring a scanner object to take the input.
		int userInput;
		int count=0;
		do{
			System.out.println("Please enter a positive integer, 2 or larger: ");
			userInput=obj.nextInt();
		}while(userInput <2);
		
		for(int i=2;i<=userInput;i++){
			
			count=count+i;
		}
		
		System.out.println("The sum of the numbers is "+count);
	}
}
