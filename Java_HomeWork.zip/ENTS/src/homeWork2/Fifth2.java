package homeWork2;

import java.util.Arrays;
import java.util.Scanner;

public class Fifth2 {

	public static void main(String[] args) {
		
		Scanner obj=new Scanner(System.in); //Declaring a scanner object to take the input.
		int userInput = 0;
		String input;
		int a=0,b=0,c=0,d=0,f=0,e=0;
		String as="",bs="",cs="",ds="",fs="";
		
		do{
			System.out.println("Please enter the number of students:");
			//if(userInput<0)System.out.println("Error! Please enter a valid number");
			userInput=obj.nextInt();
		}while(userInput<0);
		
		for(int i=0;i<userInput;i++){
			
			System.out.println("Please enter the "+(i+1)+"student's grade:");
			input=obj.next();
			if(input.length()>1){
				System.out.println("The entered grade is invalid!");
				i--;
			}
			if(input.charAt(0)=='A') {
				as+='*';
			}
			else if(input.charAt(0)=='B') {
				bs+='*';
			}
			else if(input.charAt(0)=='C') {
				cs+='*';
			}
			else if(input.charAt(0)=='D') {
				ds+='*';
			}
			
			else if(input.charAt(0)=='F') {
				fs+='*';
			}
			else {
				System.out.println("The entered grade is invalid!");
				i--;
			}
			
		}
		System.out.println("As :"+as);
		System.out.println("Bs :"+bs);
		System.out.println("Cs :"+cs);
		System.out.println("Ds :"+ds);
		System.out.println("Fs :"+fs);
	}

}

