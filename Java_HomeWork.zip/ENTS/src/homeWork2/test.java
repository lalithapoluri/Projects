package homeWork2;

import java.util.Arrays;

public class test {

	public static void main(String[] args) {
		
	
		
	/*String c="Z";
	System.out.println("start");
	*/
	
	/*if (Character.toString(c.charAt(0)).matches("[A-F?]")) {
	    System.out.println("yes");
	}*/
	
	//if (c.matches("[A-F?]")) {
	 //   System.out.println("yes");
	//}
	
	}

}
