package homeWork2;

import java.util.Scanner;

public class Second {

	public static void main(String[] args) {
		int beginYr=1800;
		int endYr=2016;
		Scanner obj=new Scanner(System.in); //Declaring a scanner object to take the input.
		int userInput;
		do{
			System.out.println("Please enter a year between 1800 and 2016: ");
			userInput=obj.nextInt();
		}while(userInput <1800 || userInput>2016);
			if(userInput%400==0 || userInput%4==0 && userInput%100!=0){
				System.out.println("This is a leap year.");
			}
			else System.out.println("This is NOT a leap year.");
	}

}
