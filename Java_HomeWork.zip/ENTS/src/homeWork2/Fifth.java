package homeWork2;

import java.util.Arrays;
import java.util.Scanner;

public class Fifth {

	public static void main(String[] args) {
		
		Scanner obj=new Scanner(System.in); //Declaring a scanner object to take the input.
		int userInput;
		String input;
		
		int a=0,b=0,c=0,d=0,f=0,e=0;
		System.out.println("Please enter the number of students:");
		userInput=obj.nextInt();
		String as="";
		char bs[]=new char[userInput];
		char cs[]=new char[userInput];
		char ds[]=new char[userInput];
		char es[]=new char[userInput];
		char fs[]=new char[userInput];
		
		if(userInput<0){
			System.out.println("Error! Please enter a valid number");
			userInput=obj.nextInt();
		}
		
		for(int i=0;i<userInput;i++){
			
			System.out.println("Please enter the "+(i+1)+"student's grade:");
			input=obj.next();
			if(input.length()>1){
				System.out.println("The entered grade is invalid!");
				i--;
			}
			else if(!isValidGrade(input.charAt(0))){
				i--;
			}
			
			if(input.charAt(0)=='A') {
				//as[a]='*';
				//System.out.println(Arrays.toString(as));
				a++;
			}
			else if(input.charAt(0)=='B') {
				bs[b]='*';
				b++;	
			}
			else if(input.charAt(0)=='C') {
				cs[c]='*';
				c++;
			}
			else if(input.charAt(0)=='D') {
				ds[d]='*';
				d++;
			}
			else if(input.charAt(0)=='E') {
				es[e]='*';
				e++;
			}
			else if(input.charAt(0)=='F') {
				fs[f]='*';
				f++;
			}
			
			
		}
		//System.out.println("As :"+Arrays.toString(as).replace(",", "").replace("]", ""));
		System.out.println("Bs :"+Arrays.toString(bs).replace(",", "").replace("]", ""));
		System.out.println("Cs :"+Arrays.toString(cs).replace(",", "").replace("]", ""));
		System.out.println("Ds :"+Arrays.toString(ds).replace(",", "").replace("]", ""));
		System.out.println("Es :"+Arrays.toString(es).replace(",", "").replace("]", ""));
		System.out.println("Fs :"+Arrays.toString(fs).replace(",", "").replace("]", ""));
		
	}

	/*public static void printStars(char c,int a) {
		char symbols[]=new char[a];
		for(int i=0;i<a;i++){
			symbols[i]='*';
			System.out.println(c+"s:"+Arrays.toString(symbols));
		}
			
		
	}
*/
	public static boolean isValidGrade(char charAt) {
		// TODO Auto-generated method stub
		if (!Character.toString(charAt).matches("[A-F?]")) {
		   System.out.println("The entered grade is invalid!");
		   return false;
		}
		else return true;
		
	}
	
	
	

}
