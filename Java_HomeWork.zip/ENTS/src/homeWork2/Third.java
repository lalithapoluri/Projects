package homeWork2;

import java.util.Scanner;

public class Third {

	public static void main(String[] args) {
		System.out.println("Please enter a candidate password");
		Scanner obj=new Scanner(System.in);
		int alphabets=0;
		int numbers=0;
		String userInput =obj.next();
		
		if(userInput.length()>=6){
			for(int i=0;i<userInput.length();i++){
				
				if(Character.isLetter(userInput.charAt(i))){
					alphabets++;
				}
				
				else if(Character.isDigit(userInput.charAt(i))){
					numbers++;
				}
			}
			if(alphabets<4) System.out.println("Not a valid password - It has less than 4 letters.");
			else if(numbers<2) System.out.println("Not a valid password - It has less than 2 numbers/digits.");
			else System.out.println("It is a valid password!");
		}
		
		else System.out.println("please enter more than 6 characters ");
	}

}
