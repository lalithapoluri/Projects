package homeWork5;

import java.util.Scanner;

public class FullTimeStudentTest {

	public static void main(String[] args) {
	
		Scanner object=new Scanner(System.in);
		System.out.println("Creating Full time Student");
		System.out.println("Please enter the student's name:");
		String name = object.next();
		System.out.println("Does the student have fellowship (y/n)? ");
		String hasFellowship = object.next();
		FullTimeStudent ftobj=null;
		if(hasFellowship.equalsIgnoreCase("y")){
			ftobj=new FullTimeStudent(name, true);
		}
			else {
				ftobj=new FullTimeStudent(name, false);
			}
		System.out.println(ftobj);		
		try {
			String newClass="";
			do {// options to select the courses to the user.
				System.out.println("ENTS 640: Networks and Protocols I \n "
						+ "ENTS 644: Cool stuff in networking\n"
						+ "ENTS 649: Awesome topics in networking \n"
						+ "ENTS 688: Advanced Java for geeks \n"
						+ "Press e to exit");
				System.out.println("Select a course");
				Scanner obj1=new Scanner(System.in);
				//System.out.println(".......................................................");
				newClass = obj1.nextLine();
				//System.out.println("newClass"+newClass);
				if(!newClass.equalsIgnoreCase("e")){
				ftobj.addClass(newClass);
				}
			} while (!newClass.equalsIgnoreCase("e"));
		} catch (RuntimeException e) {
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
		finally{
		System.out.println(ftobj);
		}
		if(ftobj.verifyRegistration()){
			System.out.println("The student meets the registration requirements.");
		}
		else{
			System.out.println("The student does not meet the registration requirements.");
		}
	}

}
