package homeWork5;

import java.util.Scanner;

public class PartTimeStudentTest {

	public static void main(String[] args) {

		
		Scanner object=new Scanner(System.in);
		System.out.println("Creating a part time student.");
		System.out.println("Please enter the student's name:");
		String name = object.next();
		System.out.println("Enter the work Place");
		String workplace = object.next();
		PartTimeStudent ptobj=null;
		ptobj=new PartTimeStudent(name, workplace);
		System.out.println(ptobj);		
		try {
			String newClass="";
			do {
				System.out.println("ENTS 640: Networks and Protocols I \n "
						+ "ENTS 644: Cool stuff in networking\n"
						+ "ENTS 649: Awesome topics in networking \n"
						+ "ENTS 688: Advanced Java for geeks \n"
						+ "Press e to exit");
				System.out.println("Select a course");
				Scanner obj1=new Scanner(System.in);
				newClass = obj1.nextLine();
				if(!newClass.equalsIgnoreCase("e")){
				ptobj.addClass(newClass);
				}
			} while (!newClass.equalsIgnoreCase("e") || !ptobj.verifyRegistration());
		} catch (RuntimeException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		System.out.println(ptobj);
		if(ptobj.verifyRegistration()){
			System.out.println("The student meets the registration requirements.");
		}
		else{
			System.out.println("The student does not meet the registration requirements.");
		}
	

	}

}
