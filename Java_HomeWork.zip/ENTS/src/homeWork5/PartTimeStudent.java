package homeWork5;

public class PartTimeStudent extends Student{
	
	private String workPlace="";
	

	public PartTimeStudent(String name) {
		super(name);
	}
	public PartTimeStudent(String name, String workPlace) {
		super(name);
		this.workPlace = workPlace;
	}
	@Override
	public boolean verifyRegistration() {
		if (super.verifyRegistration()) {
			if (super.getNumClasses() <= 6) {
				return true;
			} 
		}
		return false;
	}
	
	@Override
	public String toString() {
		return super.toString()+"\n work place: "+workPlace+"\nPart-Time Student";
	}
	
	

}
