package homeWork5;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class InetAddressTest {

	public static void main(String[] args) {
		
		//getByName(), getHostAddress(), getAddress(), getByAddress(), getLocalHost(), toString().
		
		InetAddress address = null,addr = null;
		String addr1=null;
		String host=null;
		
		try {
			address = InetAddress.getByName("ece.umd.edu");
			addr = InetAddress.getByName(address.getHostAddress());
			host = addr.getHostName();
			addr1=InetAddress.getLocalHost().getHostAddress();
			
		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} 
		System.out.println("First Host :ece.umd.edu/ "+address.getHostAddress());
		System.out.println("The IpAddress of first host is :"+address.getHostAddress());
		System.out.println("The Second host name is :"+host);
		System.out.println("Local Host:"+addr1);
		
	}

}
