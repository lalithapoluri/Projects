package homeWork5;

import java.util.Scanner;

public class StudentTest {

	public static void main(String[] args) {
		creatingFullTime();

	}
	public static void creatingFullTime(){
	    
		Scanner object=new Scanner(System.in);
		String name="";
		String hasFellowship="";
		String newClass="";
		int credits=0;
		Student obj=null;
		FullTimeStudent ftobj=null;
		System.out.println("Creating a full-time student.");
		System.out.println("Please enter the student's name:");
		name=object.next();
		System.out.println("Does the student have fellowship (y/n)? ");
		hasFellowship=object.next();
		obj=new Student(name);
		System.out.println(obj);
		System.out.println("Full-time student.");
		if(hasFellowship.equalsIgnoreCase("y")){
			ftobj=new FullTimeStudent(name, true);
			System.out.println("The student has fellowship.");
		}
			else {
				ftobj=new FullTimeStudent(name, false);
				System.out.println("The student does not fellowship.");
			}
		System.out.println("Select a course");
		System.out.println("ENTS 640: Networks and Protocols I \n "
				+ "ENTS 644: Cool stuff in networking\n"
				+ "ENTS 649: Awesome topics in networking \n"
				+ "ENTS 688: Advanced Java for geeks");
		newClass=object.next();
		ftobj.addClass(newClass);
		
			}
}
