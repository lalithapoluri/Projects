package homeWork5;

import java.util.Arrays;

import javax.management.RuntimeErrorException;

public class Student {
	
	private static final int MAX_NUM_CLASSES=4;
	
	private static final int CREDITS_PER_CLASS=3;
	
	private int count=0;
	
	private String name="";
	
	String[] classes = new String[4];
	
	private int numClasses=0;

	public Student(String name) {
		super();
		this.name = name;
	}

	public int getNumClasses() {
		return numClasses;
	}

	public void setNumClasses(int numClasses) {
		this.numClasses = numClasses;
	}
	
	public boolean verifyRegistration(){
		
		if(!classes[0].equals(null)){
			return true;
		}
		else return false;
	}

	@Override
	public String toString() {
		String array="";
		for(int i=0;i<classes.length;i++)
		{
		   if (classes[i]!=null) {
			   array=array+classes[i]+"\n";
			  // System.out.println(array);
		    // System.out.println(classes[i]);
		   }
		}      
		
		return "Student Object : name= " + name + "\nclasses :"
				+ array + "\n number of credits =" + numClasses ;
	}
	public void addClass(String newclass) throws RuntimeException{
		//System.out.println("count"+count);
		if (count<4) {
			System.out.println("Trying to add class.");
			numClasses = CREDITS_PER_CLASS * (count + 1);
			classes[count] = newclass;
			count = count + 1;
		}
		else {
			Error e = null;
			throw new RuntimeErrorException(e, "Ooops! An exception occurred! The error message is: Students cannot register "
					+ "for more than 4 classes.");
		}
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String[] getClasses() {
		return classes;
	}

	public void setClasses(String[] classes) {
		this.classes = classes;
	}
}
