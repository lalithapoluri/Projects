package homeWork5;

public class FullTimeStudent extends Student{
	
	private boolean hasFellowship=false;
	//private String name;

	public FullTimeStudent(String name) {
		super(name);
	}

	public FullTimeStudent(String name, boolean hasFellowship) {
		super(name);
		this.hasFellowship = hasFellowship;
	}
	
	
		@Override
	public boolean verifyRegistration() {
			if(super.getNumClasses()>9){
				return true;
			}
			else return false;
	}

		@Override
		public String toString() {
			if(hasFellowship){
				System.out.println("The student has fellowship.");
			}else System.out.println("The student does not have fellowship.");
			return super.toString()+"\nFull-Time Student";
					
		}
}
