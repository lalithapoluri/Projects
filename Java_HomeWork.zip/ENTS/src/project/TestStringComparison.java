package project;

public class TestStringComparison {

	public static void main(String[] args) {
	
		
		String message="<request>"
				+ "<id></id>"
				+ "<measurement></measurement>"
				+ "</request>";
		
		String message2="<request>"
				+ "<id></id>"
				+ "<measurement></measurement>"
				+ "</request>";
		
		if(message.equals(message2)){
			System.out.println("Can be comparable");
		}
		else{
			System.out.println("Cannot compare");
		}
	}

}
