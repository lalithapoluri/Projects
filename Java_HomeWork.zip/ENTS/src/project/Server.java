package project;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
//import java.nio.charset.Charset;
import java.util.ArrayList;
//import java.util.Arrays;
import java.util.List;

public class Server {

	public static void main(String args[]) throws Exception

	{
		int portValue = 7363;
		DatagramSocket serverSocket = new DatagramSocket(portValue);
		byte[] receiveData = new byte[1024];
		byte[] sendData = null;
		int code = 0, cSServer = 0, cSClient = 0, codeValue = 0;
		int checksumResp = 0;
		boolean ischeckSumEqual = false;
		boolean isCorrectSyntax = false;
		String value = "";
		String newMsgwithoutCS = "";
		List<String> clientValues = new ArrayList<String>();
		ServerMethods serverObj = new ServerMethods();
		DatagramPacket receivePacket = new DatagramPacket(receiveData,
				receiveData.length);
		while (true) {
			System.out.println("Waiting for Client...");
			serverSocket.receive(receivePacket);
			String message = new String(receivePacket.getData(), 0,
					receivePacket.getLength()); // Message from the request.
			System.out.println("Request received from Client: \n" + message);
			InetAddress IPAddress = receivePacket.getAddress();
			int port = receivePacket.getPort();
			cSClient = serverObj.getChecksumFromClient(message);// checksum from the client.
			newMsgwithoutCS = serverObj.getNewMsgwoCSUM(); // Message without the checksum value.
			// System.out.println("Message from client without Chechsum : \n"+newMsgwithoutCS);
			clientValues = serverObj.getClientValues();// The data values from the request.
			System.out.println("Information from Client :\nID :"
					+ clientValues.get(0) + "\nMeasurent ID :"
					+ clientValues.get(1) + "\nCheckSum :"
					+ clientValues.get(2));
			cSServer = serverObj.getCheckSumServer(newMsgwithoutCS);// checksum calculated by the server.
			value = serverObj.getCorresTemp(clientValues.get(1));// corresponding temp value.
			System.out.println("Corresponding Temperature :" + value
					+ "\nCheckSum From Server :" + cSServer);
			ischeckSumEqual = serverObj.isCheckSumEqual(cSServer, cSClient); // boolean to checksum equal.
			isCorrectSyntax = serverObj.isCorrectSyntax(newMsgwithoutCS);// boolean to check if syntax is correct.
			if (value != null && !value.isEmpty()) {
				codeValue = 0;
			} else {
				codeValue = 3;
			}
			code = serverObj.getCode(ischeckSumEqual, isCorrectSyntax,
					codeValue); // code to be sent in the response.
			String msgFromServer;
			if (code == 0) {
				msgFromServer = "<response>\n" + "\t<id>" + clientValues.get(0)
						+ "</id>\n" + "\t<code>" + code + "</code>\n"
						+ "\t<measurement>" + clientValues.get(1)
						+ "</measurement>\n" + "\t<value>" + value
						+ "</value>\n" + "</response>\n";
			} else {
				msgFromServer = "<response>\n" + "\t<id>" + clientValues.get(0)
						+ "</id>\n" + "\t<code>" + code + "</code>\n"
						+ "</response>\n";
			}
			checksumResp = serverObj.getCheckSumServer(msgFromServer);// checksum of the response.
			msgFromServer = msgFromServer + checksumResp;// response msg.
			System.out.println("Message to be sent to client :\n"
					+ msgFromServer);
			sendData = new byte[msgFromServer.length()];
			sendData = msgFromServer.getBytes();
			DatagramPacket sendPacket = new DatagramPacket(sendData,
					sendData.length, IPAddress, port);
			serverSocket.send(sendPacket);
		}

	}

}
