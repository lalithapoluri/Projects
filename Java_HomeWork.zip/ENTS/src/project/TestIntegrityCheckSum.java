package project;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Scanner;
public class TestIntegrityCheckSum {

	public static void main(String[] args) {

			int id=0;
			int len=0;
			int checkSumValue=0;
			 int k=0;
			 int consecAdded16digit=0;
			 int[] array = {};
			 int measurementID=0;
			 String[] dataValues = new String[200];

			
			id = (int) (Math.random() * 65536);
			String fileName = "data.txt";
			int i=0;
			int randomVariable=(int) (Math.random()*100);
			//System.out.println(randomVariable);
			try {
				FileReader fileReader = new FileReader(fileName);
				 Scanner scanner = new Scanner(fileReader);
				while(scanner.hasNextLine()){
					 dataValues[i]=scanner.next();
	     	    	i++;
	     	    }    
	     	 // System.out.println(Arrays.toString(dataValues)); 
	     	 measurementID = Integer.parseInt(dataValues[randomVariable*2]);
	     	  System.out.println("Measurement Id randomly generated:  "+measurementID);
			} catch (FileNotFoundException ex) {
				System.out.println("Unable to open file '" + fileName + "'");
			} 
			
			String message="<request>\n"+
			                "\t<id>"+id+"</id>\n"+
			                "\t<measurement>"+measurementID+"</measurement>\n"+
			                "</request>\n";
			
			System.out.println(message);
			byte[] b1 = message.getBytes(Charset.forName("UTF-8"));
			System.out.println(b1.length);
			System.out.println(Arrays.toString(b1));
			
			if(b1.length%2==0){
				len=(b1.length)/2;
			}
			else len=(b1.length+1)/2;
			array = new int[len];
			 
			 for(int i1=0;i1<len;i1++){
				 if(k>len){
					 consecAdded16digit= (256*b1[k])+0;
				 }
				 else{
				  consecAdded16digit= (256*b1[k])+b1[k+1];
				 }
				 array[i1]=consecAdded16digit;
				 k=k+2;
				
			 }
			 System.out.println(Arrays.toString(array));
			 checkSumValue= getChecksum(array);
	}
	private static int getChecksum(int[] array) {

		int s=0;
		int index=0;
		for(int i=0;i<array.length;i++){
			index=s^array[i];
			System.out.println("index: "+index);
			s=(7919*index)%65536;
		System.out.println("s: "+s);
		}
		System.out.println("Estimated checksum: "+s);
		return s;
	}
}
