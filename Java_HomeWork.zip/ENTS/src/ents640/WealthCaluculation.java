package ents640;

import java.util.Scanner;

public class WealthCaluculation {

	public static void main(String[] args) {

		Scanner scannerObject=new Scanner(System.in);
		System.out.println("Please enter the number of years (at least 1)");
		int userInput=scannerObject.nextInt();
		double intialResult=100;
		
		if(userInput<0){
			System.exit(0);
		}
		for(int i=0;i<userInput;i++){
			double result= intialResult+ (3*intialResult/100)+100;
			System.out.println("The wealth at the end of the "+(i+1)+" year is "+ result);
			intialResult=result;
		}

	}

}
