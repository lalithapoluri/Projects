package ents640.homework1;

import java.util.Scanner;
/*Enter three values: the user�s credit score, his/her annual income, and the amount of his/her current debt
credit score is less than 600 - denied.
If the credit score >= 600 and If the debt >= 20k (20000), the request should be denied.
If the debt < 20k, 50k or more annual income, credit score > 600- approved
< 50k annual income, credit score >= 700 - approved */

public class Third {

	public static void main(String[] args) {
		Scanner obj=new Scanner(System.in);
		
		System.out.println("Please enter your credit score:");
		int creditScore=obj.nextInt();
		
		System.out.println("Please enter your annual income:");
		int annualIncome=obj.nextInt();
		
		System.out.println("Please enter the amount of your current debt:");
		int currentDebt=obj.nextInt();
		
		if(creditScore>0 && annualIncome>0 && currentDebt>0){  // to check if the money value is positive or not
			if(creditScore>=600){ // to check if the credit score is >=600
					if(currentDebt<=20000){ // to check the currentDebt is less than 20000
						if(annualIncome>=50000){ // 
							System.out.println("Congratulations! Your loan request has been approved.");
						}
						else if(annualIncome<50000){ // to check if the annual income is less than 5000.
							if(creditScore>=700){
								System.out.println("Congratulations! Your loan request has been approved.");
							}
						}
					}
					else System.out.println("Sorry, your loan request has been denied.");
			}
			else System.out.println("Sorry, your loan request has been denied.");
		}
		else System.out.println("Invalid Input.");
	}
}
