package ents640.homework1;

import java.util.Scanner;
/*Risk tolerance range [0, 1].
0.9 ≤ score	 ≤ 1.0 Very high
0.6 ≤ score	 < 0.9 High
0.4 ≤ score	 < 0.6 Moderate
score	 < 0.4 Low   */
public class Second {
	public static void main(String[] args) {
		Scanner obj=new Scanner(System.in); // Scanner object initiation.
		double userInput;
		do{
			System.out.println("Please enter your risk tolerance score (0-1):");
			userInput=obj.nextDouble();
		}while(userInput<0 || userInput>1);
		
		if(userInput>=0.9 && userInput<=1){ // if and else loops to determine the condition.
			
			System.out.println("Your risk tolerance is VERY HIGH");
		}
		else if(userInput>=0.6 && userInput<0.9){
			
			System.out.println("Your risk tolerance is HIGH");
		}
		else if(userInput>=0.4 && userInput<0.6){
			
			System.out.println("Your risk tolerance is MODERATE");
		}
		else System.out.println("Your risk tolerance is low");
	}

}
