package ents640.homework1;

import java.util.Scanner;

/*This code controls the display of an elevator in an office building. The program takes the
floor number as input, and displays the appropriate information according to the table below:
Floor Display message
-1 Garage level
1 Ground floor, lobby
2 Second floor, White and Associates
3 Third floor, Margaret Creamer MD, dentist
4 Fourth floor, InLine Medical Research, General Technologies*/

public class First {

	public static void main(String[] args) {
		
		Scanner obj=new Scanner(System.in); //Declaring a scanner object to take the input.
		int userInput;
		System.out.println("Please enter the floor number (-1 to 4): ");
		userInput=obj.nextInt(); // Storing the userInput in a variable
			switch(userInput){ // Start of switch case.
				case -1:
					System.out.println("Garage level");
					break;
				case 1:
					System.out.println("Ground floor, lobby");
					break;	
				case 2:
					System.out.println("Second floor, White and Associates");
					break;
				case 3:
					System.out.println("Third floor, Margaret Creamer MD, dentist");
					break;
				case 4:
					System.out.println("Fourth floor, InLine Medical Research, General Technologies");
					break;
				default: // if the case doesn't exist then default loop is executed.
					System.out.println("You have entered an invalid floor number.");
					break;
		}
	}

}
