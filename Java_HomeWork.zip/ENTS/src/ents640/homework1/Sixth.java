package ents640.homework1;

import java.util.Scanner;
/*Java program that converts a base-7 number, which is at most 4 digits long, to a base-10 number.
First, the program should prompt the user to enter a base-7 number, and take the input as a String
(delineated by white space). It should check if the number of digits in the entered number is at most four.
If not, the program should terminate with an error message. You can terminate your program anywhere by
calling the System.exit(0) static method. Then, it should convert the entered number digit by digit and
calculate and display the base-10 representation of that number. Before processing each digit, the program
should check if the current character is a valid base-7 digit, and if not, it should terminate with an error
message, indicating which character was in error. Note that you cannot use any number converter
functionality from the Java library: you need to write the number conversion code yourself. Hint: You can
convert a character to a number by subtracting �0� (the character code of the �0� character) from the
character value.*/
public class Sixth {
	
	public static void main(String[] args) {
		String userInput="";
		Scanner object=new Scanner(System.in);
		System.out.println("Please enter an at most 4-digit base 7 number: ");
		userInput=object.next();
		if(userInput.length()<=4){
			int sum=0;
			for(int i=0;i<userInput.length();i++){
				char eachChar=userInput.charAt(i);
				if (Character.isDigit(eachChar)) {
					int value=userInput.charAt(i)-'0';
					sum=(int) (sum+(value*Math.pow(7, userInput.length()-1-i)));
					}
				else{
					System.out.println("Error! Invalid digit "+userInput.charAt(i)+" in the number.");
					System.exit(0);
				}
			}
			System.out.println("The base 10 value of the number is: "+sum);
		}
		else {
			System.out.println("Please enter atmost 4 digit value ");
		}
	}
		
	}


