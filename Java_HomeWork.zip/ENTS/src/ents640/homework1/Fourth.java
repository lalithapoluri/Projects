package ents640.homework1;

import java.util.Scanner;

/*Java program that displays the largest number entered so far. First, it should prompt the user to
enter a nonnegative number and keep repeating the prompt until a positive number, or zero is entered.
0 - the program should terminate its execution.*/

public class Fourth {
	public static void main(String[] args) {
		Scanner scannerObject=new Scanner(System.in);
		int userInput=0;
		int largestNumber=0;
		do{
			System.out.println("Please enter a positive number (0 to quit):");
			userInput=scannerObject.nextInt();
				if(userInput>0 && userInput>largestNumber){
					largestNumber=userInput; // Updates the largest number if the entered number
												//is greater than previous
				}
				if(userInput>0) System.out.println("The largest integer entered so far is : "+largestNumber);
				if(userInput==0) System.out.println("Done");
		}while(userInput!=0 || userInput<0);
	}
}
