package ents640.homework1;

import java.util.Scanner;
/*Java program that calculates the wealth of an individual called Joe. Joe started with an initial
wealth of $100. He put this money in the beginning of the 1st year into an investment account, which
yields a 3% return by the end of the year. He also managed to save (i.e. not spend) another $100 during
the year, so he had a total wealth of $103+$100=$203 at the end of the 1st year. He continued using the
same investment policy: he invested all of his wealth at the beginning of each year in an investment
account that produces an annual return of 3%, and he also saved $100 each year. Thus, at the end of the
second year, he had $209.09+$100=$309.09. The program should prompt the user to enter the length of
the period (the number of years, an integer value), and calculate Joe�s wealth each year. It is enough to
show only two decimal places of the fractional part of the results, corresponding to the cents. If the user
enters an integer value that is less one, the program should terminate with an error message.*/
public class Fifth {
	public static void main(String[] args) {
		Scanner scannerObject=new Scanner(System.in);
		System.out.println("Please enter the number of years (at least 1)");
		int userInput=scannerObject.nextInt();
		double intialResult=100; //Initialisation of value.
		if(userInput<1){// if the user enters a value less than 0ne. The program will exit.
			System.out.println("Invalid Input");
			System.exit(0);
		}
		for(int i=0;i<userInput;i++){
			double result= intialResult+ (3*intialResult/100)+100; // the formula to calculate
				System.out.printf("The wealth at the end of the "+(i+1)+" year is %.2f", result);
				System.out.println("\n");
				intialResult=result;
		}
	}
}
