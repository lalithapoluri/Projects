package ents640;

import java.util.Scanner;

public class RiskTolerance {

	public static void main(String[] args) {

		
		Scanner userInput=new Scanner(System.in);
		double t;
		do{
		System.out.println("Please enter your risk tolerance score (0-1):");
		t=userInput.nextDouble();
		}while(t<0 || t>1);
		
		if(t>=0.9 && t<=1){
			
			System.out.println("Your risk tolerance is VERY HIGH");
		}
		
		else if(t>=0.6 && t<=0.9){
			
			System.out.println("Your risk tolerance is HIGH");
		}
		
		else if(t>=0.4 && t<=0.6){
			
			System.out.println("Your risk tolerance is MODERATE");
		}
		
		else System.out.println("Your risk tolerance is low");

	}

}
