package ents640;

import java.util.Scanner;

public class LoanApproval {

	public static void main(String[] args) {
		Scanner userInput=new Scanner(System.in);
		System.out.println("Please enter your credit score:");
		double creditScore=userInput.nextDouble();
		
		System.out.println("Please enter your annual income:");
		double annualIncome=userInput.nextDouble();
		
		System.out.println("Please enter the amount of your current debt:");
		double currentDebt=userInput.nextDouble();
		if(creditScore>0 && annualIncome>0 && currentDebt>0){
		if(creditScore>=600){
			{
			if(currentDebt<=20000){
				if(annualIncome>=50000){
					System.out.println("Congratulations! Your loan request has been approved.");
				}
				else if(annualIncome<50000){
					if(creditScore>=700){
						System.out.println("Congratulations! Your loan request has been approved.");
					}
					
				}
			}
			}
		}
		else System.out.println("Sorry, your loan request has been denied.");
		}
		
		else System.out.println("Invalid Input.");
	}

}
