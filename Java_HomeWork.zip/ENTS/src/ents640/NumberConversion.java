package ents640;

import java.util.Scanner;

public class NumberConversion {
	
	public static void main(String[] args) {
		
		
		String userInput="";
		Scanner object=new Scanner(System.in);
		
		System.out.println("Please enter an at most 4-digit base 7 number: ");
		userInput=object.next();
		if(userInput.length()<=4){
			int sum=0;
			for(int i=0;i<userInput.length();i++){
				
				char eachChar=userInput.charAt(i);
				
				if (Character.isDigit(eachChar)) {
					
					int value=userInput.charAt(i)-'0';
					sum=(int) (sum+(value*Math.pow(7, userInput.length()-1-i)));
			}
				else{
					
					System.out.println("Error! Invalid digit "+userInput.charAt(i)+" in the number.");
					System.exit(0);
				}
				
			}
			System.out.println("The base 10 value of the number is: "+sum);
		}
		else {
			
			System.out.println("Please enter atmost 4 digit value ");
		}
	}
		
	}


