package ents640;

import java.util.Scanner;

public class LiftInformatiom {

	public static void main(String[] args) {
		
		Scanner userInput=new Scanner(System.in);
		int t;
		do{
			System.out.println("Please enter the floor number (-1 to 4): \nPress 0 to exit ");
			t=userInput.nextInt();
		switch(t){
		
		case -1:
			System.out.println("Garage level");
			break;
		case 1:
			System.out.println("Ground floor, lobby");
			break;	
		case 2:
			System.out.println("Second floor, White and Associates");
			break;
		case 3:
			System.out.println("Third floor, Margaret Creamer MD, dentist");
			break;
		case 4:
			System.out.println("Fourth floor, InLine Medical Research, General Technologies");
			break;
		case 0:
			break;
			
		default:
			System.out.println("You have entered an invalid floor number.");
			break;
		
		}
		}while(t!=0);

	}

}
