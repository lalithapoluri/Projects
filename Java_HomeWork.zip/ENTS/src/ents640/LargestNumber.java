package ents640;

import java.util.Scanner;

public class LargestNumber {

	public static void main(String[] args) {
		Scanner scannerObject=new Scanner(System.in);
		int userInput=0;
		int largestNumber=0;
		do{
		System.out.println("Please enter a positive number (0 to quit):");
		userInput=scannerObject.nextInt();
		if(userInput>0 && userInput>largestNumber){
			largestNumber=userInput;
		}
		if(userInput>0) System.out.println("The largest integer entered so far is : "+largestNumber);
		if(userInput==0) System.out.println("Done");
		}while(userInput!=0 || userInput<0);
	}

}
