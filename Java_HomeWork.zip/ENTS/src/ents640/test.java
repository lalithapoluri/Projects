package ents640;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double value = 200.3456;
		System.out.printf("Value: %.2f", value);
	}

}
