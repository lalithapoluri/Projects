package homeWork3;

public class Root {

	public static void main(String[] args) {
		
		double upper=(Math.PI)/2;
		double lower=0.0;
		double tolerance=Math.pow(10, -7);
		double result=solver(lower,upper,tolerance);
		System.out.println("The solution is: x = "+result);
	}
	
	public static double solver(double lower, double upper, double tolerance){
		double lowerValue=lower;
		double upperValue=upper;
		double middleValue=0.0;
		double funcResult=0.0;
		int i=1;
		do{
			System.out.println(""+i+": iteration: lower: "+lowerValue+", upper: "+upperValue);
			middleValue=(lowerValue+upperValue)/2;
			funcResult=function(middleValue);
			if(funcResult>0){
				upperValue=middleValue;
			}
			else{
				lowerValue=middleValue;
			}
			i++;
		}while(Math.abs(upperValue-lowerValue)>tolerance);
		
	return middleValue;	
	}
	
	public static double function(double x){
		return (Math.sqrt(x)-(Math.cos(x)));
	}

}
