package homeWork3;

import java.util.Scanner;

public class SecondLargest {

	public static void main(String[] args) {
		
		 Scanner scannerObject=new Scanner(System.in);

		    System.out.println("Enter the length of an array: ");

		    int arrayLength=scannerObject.nextInt();

		    double[] userInput=new double[arrayLength];
		    
		    for(int i=0;i<arrayLength;i++){//for reading array
		    	 System.out.printf("Enter "+(i+1)+"st Element: ");
		    	userInput[i]=scannerObject.nextDouble();
		    	System.out.println(userInput[i]);

		    }
		
		double secondLargest= findSecondLargest(userInput);
		
		System.out.println("The Second largest "+secondLargest);
	}
	private static double findSecondLargest(double[] input) {
		double largest=0.0;
		double secondLargest=0.0;
		if(input.length>2){
			if(input[0] > input[1]) {
				largest = input[0];
				secondLargest = input[1];
			}
			else {
				largest = input[1];
				secondLargest = input[0];
			}
				for(int i = 2; i < input.length; i++) {
					if((input[i] <= largest) && input[i] > secondLargest) {
						secondLargest = input[i];
					}
					if(input[i] > largest) {
						secondLargest = largest;
						largest = input[i];
					}
				}
		}
		else {
			secondLargest=input[0];
		}
		return secondLargest;
	}
}
