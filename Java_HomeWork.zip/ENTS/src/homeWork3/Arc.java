package homeWork3;

public class Arc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double v=1;
		double p=1e-4;
		double preSum=0;
		int ind=0;
ArcTangent.calcArcTangent(v,p,preSum,ind);
double z=Math.atan(v);
System.out.println();
System.out.print("The exact value is: ");
System.out.print(z);
	}

}
