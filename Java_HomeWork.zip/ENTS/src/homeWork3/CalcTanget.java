package homeWork3;

import java.util.Scanner;

public class CalcTanget {

	public static void main(String[] args) {
		Scanner obj=new Scanner(System.in);
		System.out.println("Enter the value of x: ");
		int x=obj.nextInt();
		double tanValue=calcArcTangent(x, Math.pow(10, -4));
		System.out.printf("Tanvalue %.6f \n",tanValue);
		System.out.printf("The accurate value is: %.6f",Math.atan(x));
	}
	private static double calcArcTangent(int x, double precision) {
		int i=0;
		double value;
		double sum=0.0;
		double previousSum=0.0;
		do{
			previousSum=sum;
			value=Math.pow(x,(2*i+1))*Math.pow((-1),i)/(2*i+1);
			sum=sum+value;
			i++;
		}while(Math.abs(sum-previousSum)>precision);
		return sum;
	}
}
