package homeWork3;

import java.util.Scanner;

public class CalcTangetRecursive {

	public static void main(String[] args) {
		double prevSum=0.0;
		Scanner obj=new Scanner(System.in);
		int ind=0;
		System.out.println("Enter the value of x: ");
		int x=obj.nextInt();
		calcArcTangent(x,Math.pow(10, -4), prevSum, ind);
		
		System.out.printf("The accurate value is: %.6f",Math.atan(x));
	}

	
	public static double calcArcTangent(double x, double precision, double prevSum, int ind){
		double sum=0.0;
		double value=0.0;
		
		value=Math.pow(x,(2*ind+1))*Math.pow((-1),ind)/(2*ind+1);
		sum=prevSum+value;
		//System.out.println("sum"+sum);
		   if(Math.abs((sum-prevSum))<precision){
			   System.out.printf("The approximate result is:%.6f ",sum);
			   System.out.println();
			return sum;
		   }
		   else
		          {
				ind++;
				calcArcTangent(x,precision,sum,ind);
		          return sum;
		          }
	}
}
