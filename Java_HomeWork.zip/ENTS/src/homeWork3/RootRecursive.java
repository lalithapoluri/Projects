package homeWork3;

public class RootRecursive {
	
	public static double solver(double lower, double upper,  int count, double tolerance)
	{
		double middleValue=0;
		
			System.out.printf("%d .iteration: lower=%.10f, upper=%.10f",(count+1),lower,upper);
			System.out.println();
			middleValue=(upper+lower)/2;
			double funcResult=function(middleValue);
			if(funcResult>0)
			{
			upper=middleValue;
			}
			
			if(funcResult<0)
			{
				lower=middleValue;
			}
			if(upper-lower<tolerance)
			{
				System.out.printf("The solution is : %f",middleValue);
			}
			else
			{
				count++;
				solver(lower,upper,count,tolerance);
			}
		
		return middleValue;
	}
	public static double function(double x) 
	{
		double f= Math.sqrt(x) - java.lang.Math.cos(x);
		return f;
	}


	public static void main(String[] args) {
			// TODO Auto-generated method stub
		double upper=(Math.PI)/2;
		double lower=0.0;
		double tolerance=Math.pow(10, -7);
		int count=0;
		double result=solver(lower,upper,count,tolerance);
	}

}
