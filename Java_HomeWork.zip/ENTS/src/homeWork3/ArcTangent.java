package homeWork3;


public class ArcTangent {

	public static double calcArcTangent(double x, double e,double preSum, int ind)
	{
		// TODO Auto-generated method stub
		double Sum1=0;
		//double Sum=0;
		double S1=0;
		double q=0;
		//primitive initialized to 0, boolean init to false, objects init to null.
		
			S1=Math.pow(-1,ind)/(2*ind+1)*Math.pow(x,2*ind+1);
			 
			 q=Math.abs(preSum-Sum1);
			 //dont mess with input values 
			 Sum1= preSum + S1;
			 q=Math.abs(Sum1-preSum);
			if(q<e)//called base case or condition
		   {
			   System.out.print("The approximate result is: ");
			   System.out.print(Sum1);
		
			  return Sum1;
		   }
		   else{  
			   ind++;
			   calcArcTangent(x,e,Sum1,ind); //Stack Overflow error 
			   //something wrong with termination
		   }
	return Sum1;	
	}

}




