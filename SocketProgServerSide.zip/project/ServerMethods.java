package project;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ServerMethods {

	private String newMsgwoCSUM = "";
	private List<String> clientValues = new ArrayList<String>();

	public List<String> getClientValues() {
		return clientValues;
	}

	public void setClientValues(List<String> clientValues) {
		this.clientValues = clientValues;
	}

	public String getNewMsgwoCSUM() {
		return newMsgwoCSUM;
	}

	public void setNewMsgwoCSUM(String newMsgwoCSUM) {
		this.newMsgwoCSUM = newMsgwoCSUM;
	}

	public int getChecksumFromClient(String message) {

		String message1 = message.replaceAll("[^-?0-9]+", " ");
		clientValues = Arrays.asList(message1.trim().split(" "));
		newMsgwoCSUM = message.replace(clientValues.get(2), "");
		return Integer.parseInt(clientValues.get(2));
	}

	/*
	 * Method: Gets the msg from the client. All the spaces are removed and
	 * compared with a std string value.
	 */
	public boolean isCorrectSyntax(String message) {
		String s = message.replaceAll("\\>.*?\\<", "><").replaceAll("\\s", "");
		// System.out.println("After replacing \n"+s);
		String defaultString = "<request><id></id><measurement></measurement></request>";
		if (s.equals(defaultString)) {
			System.out.println("Correct Syntax");
			return true;
		} else {
			System.out.println("Error in Syntax");
			return false;
		}
	}

	/*
	 * Method : Calculates the checksum from message. Bytes of the Msg are taken
	 * converted to 16 bit values. The array is passed to getChecksum Method.
	 */
	public int getCheckSumServer(String message) {

		int len = 0;
		int checkSumValue = 0;
		int k = 0;
		int consecAdded16digit = 0;
		int[] array = {};
		byte[] b1 = message.getBytes(Charset.forName("UTF-8"));
		if (b1.length % 2 == 0) {
			len = (b1.length) / 2;
		} else
			len = (b1.length + 1) / 2;
		array = new int[len];

		for (int i = 0; i < len; i++) {
			if (k > len) {
				consecAdded16digit = (256 * b1[k]) + 0;
			} else {
				consecAdded16digit = (256 * b1[k]) + b1[k + 1];
			}
			array[i] = consecAdded16digit;
			k = k + 2;
		}
		// System.out.println(Arrays.toString(array));
		checkSumValue = getChecksum(array);
		return checkSumValue;
	}

	/*
	 * Method: Gets the array. Index= s XOR array[i] s=(7919*index)MOD 65536.
	 */
	private int getChecksum(int[] array) {
		int s = 0;
		int index = 0;
		for (int i = 0; i < array.length; i++) {
			index = s ^ array[i];
			s = (7919 * index) % 65536;
		}
		// System.out.println("Estimated checksum: " + s);
		return s;
	}

	public int getCode(boolean ischeckSumEqual, boolean isCorrectSyntax,
			int codeValue) {

		if (!isCorrectSyntax)
			return 2;
		else if (codeValue == 3)
			return codeValue;
		else if (!ischeckSumEqual)
			return 1;
		else
			return 0;
	}

	/*
	 * Method: gets the MeasurementID. Checks for the line which contains the
	 * Id. returns the corresponding temperature value.
	 */
	public String getCorresTemp(String mID) {
		String fileName = "data.txt";
		String s = null;
		String line = null;
		try {
			FileReader fileReader = new FileReader(fileName);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			while ((line = bufferedReader.readLine()) != null) {
				if (line.contains(mID)) {
					Scanner s2 = new Scanner(line);
					while (s2.hasNext()) {
						s = s2.next();
					}
					// System.out.println(s);
				}
			}
			bufferedReader.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + fileName + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + fileName + "'");
		}

		return s;
	}

	public boolean isCheckSumEqual(int csFromServer, int csFromClient) {
		if (csFromServer == csFromClient)
			return true;
		else
			return false;

	}
}
