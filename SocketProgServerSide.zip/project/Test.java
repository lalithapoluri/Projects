package project;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test {

	public static void main(String[] args) {
		
		int iD=1;
		int measureID=83429;
		List<String> p = new ArrayList<String>();
		String nf="";
		
		String message="<request1234>\n" + "\t<id>" + iD + "</id>\n"
				+ "\t<measurement>" + measureID + "</measurement>\n"
				+ "</request>\n5643";
		
		Pattern p1 = Pattern.compile("\\>(.*?)\\<");
		Matcher m = p1.matcher(message);
		while(m.find())
		{
		   System.out.println(m.group(1)); //is your string. do what you want
		   nf=m.group(1);
		}
		//String message1 = message.replaceAll("[^-?0-9]+", " ");
		//p = Arrays.asList(m.group(1).trim().split(" "));
		
		p = Arrays.asList(nf.trim().split(" "));
		System.out.println(p.get(1));
		
		    
	}

}
