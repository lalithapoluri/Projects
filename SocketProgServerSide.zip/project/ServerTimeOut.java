package project;
import java.net.*;


public class ServerTimeOut {

	public static void main(String args[]) throws Exception

	{
		int port1=8644;
	DatagramSocket serverSocket = new DatagramSocket(port1);

	//Server Socekt Created

	byte[] receiveData = new byte[1024];

	byte[] sendData = new byte[1024];

	System.out.println("jaja");
	DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
	//Change sentence to Capital letter

	while (true) {
		serverSocket.receive(receivePacket);
		System.out.println("haha");
		String sentence = new String(receivePacket.getData());
		System.out.println("RECEIVED: " + sentence);
		InetAddress IPAddress = receivePacket.getAddress();
		int port = receivePacket.getPort();
		String capitalizedSentence = sentence.toUpperCase();
		sendData = capitalizedSentence.getBytes();
		DatagramPacket sendPacket =

		new DatagramPacket(sendData, sendData.length, IPAddress, port);
		serverSocket.send(sendPacket);
		System.out.println("Sending to client");
	}

	//Send Capitalized data back to client

	}

	}

	

