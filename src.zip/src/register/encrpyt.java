package register;



public class encrpyt {
	


	public static void main(String[] args) {
		
		
		
	}

}


/*String pwd="lalitha";


int sum=0;
int j=0;

for(int i=0;i<pwd.length();i++){
	
char character = pwd.charAt(i); // This gives the character 'a'
	int ascii = (int) character;// ascii is now 97.
	System.out.println(ascii);
	System.out.println(sum);
	System.out.println(j);
	sum=sum+ascii+j;
	j=j+1;
	
}

System.out.println(sum);
String newPwd= Integer.toString(sum);

System.out.println(newPwd);*/