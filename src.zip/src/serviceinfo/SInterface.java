package serviceinfo;
import java.sql.SQLException;
import java.util.List;

import mytravelarchitecture.*;

public interface SInterface {
	
	String registerUser(RegisterInfo info) throws SQLException;
	
	String registerTrip(RegisterInfo info) throws SQLException;

	String LoginUser(RegisterInfo info) throws SQLException;

	List<RegisterInfo> showUser() throws SQLException;

	List<RegisterInfo> showTeam() throws SQLException;
	
	List<RegisterInfo> showTrips(String team,String email) throws SQLException;
}
