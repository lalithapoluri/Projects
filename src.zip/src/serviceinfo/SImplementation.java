

package serviceinfo;
import java.sql.SQLException;
import java.util.List;

import mytravelarchitecture.*;
import daoinfo.*;



public class SImplementation implements SInterface {

	@Override
	public String registerUser(RegisterInfo info) {
		
		String bls ="fp";
		
		DInterface x = new DImplementation();
		try {
			System.out.println("enter service layer and register info" +info);
			
			x.storeuserdetails(info);
			
		//	l.info("no excepiton occured in service ");
			
			System.out.println("after register info");
			bls  ="ok";
		} catch (IllegalArgumentException e) {
		
	//		l.fatal(e,e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			bls ="iat";
		//	l.error(e,e);
		}
		return bls;
		
	}

	@Override
	public String LoginUser(RegisterInfo info) throws SQLException {
		
		System.out.println("Entered Login User");
		
		String bls ="fp";
		DInterface x = new DImplementation();
		try {
			
			System.out.println("Entered try of LoginUser");
			
			boolean vu = x.validateuser(info);
			bls = vu ? "ok" : "iu";
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bls;
	
	}

	@Override
	public List<RegisterInfo> showUser() throws SQLException {
		
		List<RegisterInfo> l = null;
		try {
			DInterface x = new DImplementation();
			 l=x.showDetailsToUser();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println(l);
		return l;
		
	}

	@Override
	public String registerTrip(RegisterInfo info) {
		
		String bls ="fp";
		
		DInterface x = new DImplementation();
		try {
			System.out.println("enter service layer and register info" +info);
			
			x.storetripdetails(info);
			
		//	l.info("no excepiton occured in service ");
			
			System.out.println("after register info");
			bls  ="ok";
		} catch (IllegalArgumentException e) {
		
	//		l.fatal(e,e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			bls ="iat";
		//	l.error(e,e);
		}
		return bls;
		
	}

	@Override
	public List<RegisterInfo> showTeam() throws SQLException {
		List<RegisterInfo> l = null;
		try {
			DInterface x = new DImplementation();
			 l=x.showTeamsToUser();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println(l);
		return l;
	}

	@Override
	public List<RegisterInfo> showTrips(String team,String email) throws SQLException {
		
		List<RegisterInfo> l = null;
		try {
			DInterface x = new DImplementation();
			 l=x.showTripsToUser(team,email);
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println(l);
		return l;
	}

}
