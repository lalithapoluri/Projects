package planTrip;

public class planbean {
	
	private String hiddenemail,tripid;

	public final String getHiddenemail() {
		return hiddenemail;
	}

	public final void setHiddenemail(String hiddenemail) {
		this.hiddenemail = hiddenemail;
	}

	public final String getTripid() {
		return tripid;
	}

	public final void setTripid(String tripid) {
		this.tripid = tripid;
	}

}
