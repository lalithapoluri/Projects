package planTrip;

public class LayoutBean {
	
	
	private String vehicleNumber;
	private String tripid;
	private String name;
	public String getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	public String getTripid() {
		return tripid;
	}
	public void setTripid(String tripid) {
		this.tripid = tripid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LayoutBean(String vehicleNumber, String tripid, String name) {
		super();
		this.vehicleNumber = vehicleNumber;
		this.tripid = tripid;
		this.name = name;
	}
	public LayoutBean() {
		super();
	}
	
	
	
	

}
