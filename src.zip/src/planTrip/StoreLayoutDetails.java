package planTrip;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import test.testbean;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import daoinfo.DImplementation;

public class StoreLayoutDetails extends ActionSupport implements ModelDriven{
	

	private static final long serialVersionUID = 1L;
	private LayoutBean x;
	
	List<LayoutBean> layoutinfo=new ArrayList<LayoutBean>();
	
	
	
	public List<LayoutBean> getLayoutinfo() {
		return layoutinfo;
	}

	public void setLayoutinfo(List<LayoutBean> layoutinfo) {
		this.layoutinfo = layoutinfo;
	}

	public String execute() throws SQLException{
		
		
		
		System.out.println(layoutinfo.get(0).getName());
		
		for(int i=0;i<layoutinfo.size();i++){
			
			System.out.println(layoutinfo.get(i).getName());
			System.out.println(layoutinfo.get(i).getTripid());
			System.out.println(layoutinfo.get(i).getVehicleNumber());
			
			
			
		}
		
		DImplementation daoobject=new DImplementation();
		daoobject.storeLayoutInfo(layoutinfo);
	
		return "success";
	
	}

	@Override
	public Object getModel() {
		x = new LayoutBean();
		return x;
	}

}
