package planTrip;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import java.util.Map;

import mytravelarchitecture.RegisterInfo;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import daoinfo.DImplementation;

public class PlanningTrips extends ActionSupport implements ModelDriven{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private planbean x;
	private List<RegisterInfo> registeredusersWithCar;
	private List<RegisterInfo> registeredusersWithBike;
	private List<RegisterInfo> registeredusersWithoutvehicle;
	
	
	
	private List<LayoutBean> layoutInfoFromDB;
	
	List<String> distinctVehNum=new ArrayList<String>();
	
	public List<LayoutBean> getLayoutInfoFromDB() {
		return layoutInfoFromDB;
	}



	public void setLayoutInfoFromDB(List<LayoutBean> layoutInfoFromDB) {
		this.layoutInfoFromDB = layoutInfoFromDB;
	}



	@Override
	public Object getModel() {
		x = new planbean();
		return x;
	}
	
	

	public List<RegisterInfo> getRegisteredusersWithCar() {
		return registeredusersWithCar;
	}



	public void setRegisteredusersWithCar(List<RegisterInfo> registeredusersWithCar) {
		this.registeredusersWithCar = registeredusersWithCar;
	}



	public List<RegisterInfo> getRegisteredusersWithBike() {
		return registeredusersWithBike;
	}



	public void setRegisteredusersWithBike(
			List<RegisterInfo> registeredusersWithBike) {
		this.registeredusersWithBike = registeredusersWithBike;
	}



	public List<RegisterInfo> getRegisteredusersWithoutvehicle() {
		return registeredusersWithoutvehicle;
	}



	public void setRegisteredusersWithoutvehicle(
			List<RegisterInfo> registeredusersWithoutvehicle) {
		this.registeredusersWithoutvehicle = registeredusersWithoutvehicle;
	}



	public String execute() throws SQLException{
		
		System.out.println(x.getHiddenemail());
		System.out.println(x.getTripid());
		
		DImplementation daoobject= new DImplementation();
		registeredusersWithCar=daoobject.showRegisteredUsersForTripWithCar(x.getTripid());
		registeredusersWithBike=daoobject.showRegisteredUsersForTripWithBike(x.getTripid());
		registeredusersWithoutvehicle=daoobject.showRegisteredUsersForTripWithoutVehicle(x.getTripid());
		
		System.out.println(registeredusersWithoutvehicle.size());
		
		
		for(int k=0;k<registeredusersWithCar.size();k++){
			
			distinctVehNum.add(registeredusersWithCar.get(k).getVehicleNumber());
			
		}
		
		for(int k=0;k<registeredusersWithBike.size();k++){
			
			distinctVehNum.add(registeredusersWithBike.get(k).getVehicleNumber());
			
		}
		
		
		
		
		
		
		layoutInfoFromDB=daoobject.fetchLayoutInfo(x.getTripid());
		Map<String,String> layoutmap = new HashMap<String,String>();
		List<String> memberList=new ArrayList<String>();
		//List<layoutInfoFromDB> list;
		
		
		for(int j=0;j<registeredusersWithCar.size();j++){
			
			
			for(int i=0;i<layoutInfoFromDB.size();i++){
				
				if(registeredusersWithCar.get(j).getVehicleNumber()==layoutInfoFromDB.get(i).getVehicleNumber()){
					
					
					//String[] peopleInOneCar;
					//peopleInOneCar.add(layoutInfoFromDB.get(i).getName());
					
					
					
					layoutmap.put(layoutInfoFromDB.get(i).getVehicleNumber(),layoutInfoFromDB.get(i).getName());
					
					//for (LayoutBean k : layoutInfoFromDB) layoutmap.put(k.getVehicleNumber(),k.getName());
					
					System.out.println(layoutmap);
					
				}
				
				
			}
			
		}
		
		
		
		
		return "success";
	}

	
	
	
	

}
