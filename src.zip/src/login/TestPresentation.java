package login;

 import java.sql.SQLException;
import java.util.List;





import serviceinfo.*;
import mytravelarchitecture.*;

import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.ActionSupport;

import daoinfo.DImplementation;

public class TestPresentation extends ActionSupport implements ModelDriven{
	

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

private Info x;
private String newPwd;
private List<RegisterInfo> teams;
private List<RegisterInfo> tripInfo;
private List<RegisterInfo> tripInfoforPlanning;
private List<RegisterInfo> tripInfowithuserstatus;


public List<RegisterInfo> getTripInfoforPlanning() {
	return tripInfoforPlanning;
}


public void setTripInfoforPlanning(List<RegisterInfo> tripInfoforPlanning) {
	this.tripInfoforPlanning = tripInfoforPlanning;
}




	public final List<RegisterInfo> getTripInfowithuserstatus() {
	return tripInfowithuserstatus;
}


public final void setTripInfowithuserstatus(
		List<RegisterInfo> tripInfowithuserstatus) {
	this.tripInfowithuserstatus = tripInfowithuserstatus;
}


	public List<RegisterInfo> getTeams() {
	return teams;
}


public void setTeams(List<RegisterInfo> teams) {
	this.teams = teams;
}


public List<RegisterInfo> getTripInfo() {
	return tripInfo;
}


public void setTripInfo(List<RegisterInfo> tripInfo) {
	this.tripInfo = tripInfo;
}


	public String execute() throws SQLException{
	
		System.out.println(" Entered Execute");
		
		
		String pwd=x.getPassword();
		int sum=0;
		int j=0;
		
		for(int i=0;i<pwd.length();i++){
			
		char character = pwd.charAt(i); // This gives the character 'a'
			int ascii = (int) character; // ascii is now 97.
			sum=sum+ascii+j;
			j=j+1;
		}
		
		System.out.println(sum);
		newPwd= Integer.toString(sum);
		
		System.out.println("the new password is" +newPwd);
	
		RegisterInfo info_login= new RegisterInfo(x.getEmail1(), newPwd);

		SInterface y=new SImplementation();
		
		

		 teams = y.showTeam();
		 System.out.println(teams);
		 
		 DImplementation daoobject= new DImplementation();
		String team = daoobject.getTeamfromEmail(x.getEmail1());
		 
		System.out.println(team);
		 
		 tripInfo=y.showTrips(team,x.getEmail1());
		 
		 tripInfowithuserstatus=daoobject.showTripsWithUserStatus(team,x.getEmail1());
		 tripInfoforPlanning=daoobject.showTripsWhichHeCanPlan(x.getEmail1());
		
		System.out.println(tripInfo);
		 
		System.out.println("completely outside for");
		String val= y.LoginUser(info_login);
		 if (val.equals("ok")   ) {
			return "success";
			
			
	        } else {
	        	addActionError(getText("error.login"));
	        	return "error";
	            //addActionError(getText("error.login")); 
	        }
		
		
	}
	

	@Override
	public Object getModel() {
		x = new Info();
		return x;
	}
	

	
	
	
}
