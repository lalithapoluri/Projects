package login;

 import java.sql.SQLException;
import java.util.List;

import serviceinfo.*;
import mytravelarchitecture.*;

import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.ActionSupport;

import daoinfo.DImplementation;

public class TestPrep2 extends ActionSupport implements ModelDriven{
	

private static final long serialVersionUID = 1L;

private InfoTestPrep2 x;

private List<RegisterInfo> teams;
private List<RegisterInfo> tripInfo;
private List<RegisterInfo> tripInfowithuserstatus;
private List<RegisterInfo> tripInfoforPlanning;
	
	
	public List<RegisterInfo> getTripInfoforPlanning() {
	return tripInfoforPlanning;
}


public void setTripInfoforPlanning(List<RegisterInfo> tripInfoforPlanning) {
	this.tripInfoforPlanning = tripInfoforPlanning;
}


	public List<RegisterInfo> getTripInfowithuserstatus() {
	return tripInfowithuserstatus;
}


public void setTripInfowithuserstatus(List<RegisterInfo> tripInfowithuserstatus) {
	this.tripInfowithuserstatus = tripInfowithuserstatus;
}


	public List<RegisterInfo> getTeams() {
	return teams;
	}


	public void setTeams(List<RegisterInfo> teams) {
	this.teams = teams;
	}


	public List<RegisterInfo> getTripInfo() {
	return tripInfo;
	}


	public void setTripInfo(List<RegisterInfo> tripInfo) {
	this.tripInfo = tripInfo;
	}


	public String execute() throws SQLException{
	
		System.out.println(" Entered Execute");
		
		System.out.println(x.getHiddenemail());
		System.out.println(x.getUserstatus());
		System.out.println(x.getTripid());
		
		
		SInterface y=new SImplementation();

		 teams = y.showTeam();
		 System.out.println(teams);
		 
		 DImplementation daoObject= new DImplementation();
		 
		String team = daoObject.getTeamfromEmail(x.getHiddenemail());
		
		System.out.println("came to store user trip details");
		daoObject.storeUserStatus(x.getHiddenemail(), x.getTripid(), x.getUserstatus());
		
		System.out.println(team);
		 
		 tripInfo=y.showTrips(team,x.getHiddenemail());
		 tripInfowithuserstatus=daoObject.showTripsWithUserStatus(team,x.getHiddenemail());
		 tripInfoforPlanning=daoObject.showTripsWhichHeCanPlan(x.getHiddenemail());
		 
		System.out.println(tripInfo);
		 
		System.out.println("completely outside for");
		
		return "success";
	}	

	@Override
	public Object getModel() {
		x = new InfoTestPrep2();
		return x;
	}
	

	
	
	
}
