package login;

public class InfoTestPrep2 {
	
	private String hiddenemail,userstatus,tripid;

	public final String getTripid() {
		return tripid;
	}

	public final void setTripid(String tripid) {
		this.tripid = tripid;
	}

	public final String getUserstatus() {
		return userstatus;
	}

	public final void setUserstatus(String userstatus) {
		this.userstatus = userstatus;
	}

	public final String getHiddenemail() {
		return hiddenemail;
	}

	public final void setHiddenemail(String hiddenemail) {
		this.hiddenemail = hiddenemail;
	}

	

	
}
