package login;

public class Logout {
	
	
	public String execute(){
		
		return "success";

}
}