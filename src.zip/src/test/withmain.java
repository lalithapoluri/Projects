package test;

public class withmain {

	public static void main(String[] args) {
		
		
		int i[]={1,2,3};
		int j[]={1,1,1,1,2,2,2,3,3};
		int count=1;
		

		for(int k=0;k<3;k++){
			
			
			for(int l=0;l<9;l++){
				
				
				if(i[k]==j[l]){
					
					count=count+1;
					
				}
				
		
			}
			System.out.println(count);
	
		}
		

	}

}
