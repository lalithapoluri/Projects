package test;

public class test2 {
	
	private String hiddenemail;

	public String getHiddenemail() {
		return hiddenemail;
	}

	public void setHiddenemail(String hiddenemail) {
		this.hiddenemail = hiddenemail;
	}
	public String execute() {
		return "success";
	}

}
