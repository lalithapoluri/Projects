package test;

public class testforloadingaction {
	
	
	//private String name="lalitha";
	
	public String execute(){
		
		int i=(int) (Math.random()*10);
		
		if(i<5){
			
			return "success";
		}
		
		else{
			
			return "error";
		}
		
	}

}
