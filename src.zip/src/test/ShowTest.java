package test;



import java.util.ArrayList;
import java.util.List;

import login.Info;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class ShowTest extends ActionSupport implements ModelDriven{
	


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private testbean x;
	private String hiddenfield;
	
	ArrayList<String> email = new ArrayList<String>();
	
	List<testbean> layoutinfo=new ArrayList<testbean>();
	
	
	public List<testbean> getLayoutinfo() {
		return layoutinfo;
	}






	public void setLayoutinfo(List<testbean> layoutinfo) {
		this.layoutinfo = layoutinfo;
	}






	public ArrayList<String> getEmail() {
		return email;
	}






	public void setEmail(ArrayList<String> email) {
		this.email = email;
	}






	public String execute() {
		System.out.println("hello");
		System.out.println(hiddenfield);
		System.out.println(email.get(0));
		System.out.println(layoutinfo);
		return "success";
	}






	public String getHiddenfield() {
		return hiddenfield;
	}






	public void setHiddenfield(String hiddenfield) {
		this.hiddenfield = hiddenfield;
	}






	@Override
	public Object getModel() {
		x = new testbean();
		return x;
	}
}