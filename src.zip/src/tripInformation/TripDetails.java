package tripInformation;


public class TripDetails {
	
	private  String tripId,tripName,tripDescription,time, venue,tripStatus,when,hiddenemail,invitedlist,teamname;
	
	

	public final String getTeamname() {
		return teamname;
	}

	public final void setTeamname(String teamname) {
		this.teamname = teamname;
	}

	public final String getInvitedlist() {
		return invitedlist;
	}

	public final void setInvitedlist(String invitedlist) {
		this.invitedlist = invitedlist;
	}

	

	


	public final String getHiddenemail() {
		return hiddenemail;
	}

	public final void setHiddenemail(String hiddenemail) {
		this.hiddenemail = hiddenemail;
	}

	public final String getTripId() {
		return tripId;
	}

	public final void setTripId(String tripId) {
		this.tripId = tripId;
	}

	public final String getTripName() {
		return tripName;
	}

	public final void setTripName(String tripName) {
		this.tripName = tripName;
	}

	public final String getTripDescription() {
		return tripDescription;
	}

	public final void setTripDescription(String tripDescription) {
		this.tripDescription = tripDescription;
	}

	
	public final String getWhen() {
		return when;
	}

	public final void setWhen(String when) {
		this.when = when;
	}

	public final String getVenue() {
		return venue;
	}

	public final void setVenue(String venue) {
		this.venue = venue;
	}

	public final String getTime() {
		return time;
	}

	public final void setTime(String time) {
		this.time = time;
	}

	public final String getTripStatus() {
		return tripStatus;
	}

	public final void setTripStatus(String tripStatus) {
		this.tripStatus = tripStatus;
	}
	
	
	

}






