package tripInformation;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import serviceinfo.SImplementation;
import serviceinfo.SInterface;
import mytravelarchitecture.*;

import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.ActionSupport;

import daoinfo.DImplementation;



public class TripClick extends ActionSupport implements ModelDriven,SessionAware{
	
	private static final long serialVersionUID = 1L;
		private TripDetails x;
		
		Map<String, Object> session;
		private List<RegisterInfo> teams;
		private List<RegisterInfo> tripInfo;
		private List<RegisterInfo> tripInfowithuserstatus;
		private List<RegisterInfo> tripInfoforPlanning;
		
		public List<RegisterInfo> getTripInfoforPlanning() {
			return tripInfoforPlanning;
		}


		public void setTripInfoforPlanning(List<RegisterInfo> tripInfoforPlanning) {
			this.tripInfoforPlanning = tripInfoforPlanning;
		}


		public List<RegisterInfo> getTripInfowithuserstatus() {
			return tripInfowithuserstatus;
		}


		public void setTripInfowithuserstatus(List<RegisterInfo> tripInfowithuserstatus) {
			this.tripInfowithuserstatus = tripInfowithuserstatus;
		}


		public List<RegisterInfo> getTeams() {
			return teams;
			}


			public void setTeams(List<RegisterInfo> teams) {
			this.teams = teams;
			}


			public List<RegisterInfo> getTripInfo() {
			return tripInfo;
			}


			public void setTripInfo(List<RegisterInfo> tripInfo) {
			this.tripInfo = tripInfo;
			}
			
		public String execute() throws SQLException{
			
			System.out.println("entered execute of trip click");
			System.out.println(x.getTeamname());
			System.out.println(x.getHiddenemail());
			String allTeamsSelected = x.getTeamname();
			
				String[] parts = allTeamsSelected.split(", ");
				String part1 = parts[0]; 
			
				System.out.println(part1);
			
			RegisterInfo info = new RegisterInfo(x.getTripId(), x.getTripName(), x.getTripDescription(), x.getVenue(), x.getTime(), x.getTripStatus(), x.getWhen(),x.getInvitedlist(),x.getHiddenemail());
			
			
			
			System.out.println(info);
			
			SInterface y=new SImplementation();

			 teams = y.showTeam();
			 System.out.println(teams);
			 
			 DImplementation daoobject= new DImplementation();
			String team = daoobject.getTeamfromEmail(x.getHiddenemail());
			 
			System.out.println(team);
			 
			 tripInfo=y.showTrips(team,x.getHiddenemail());
			 tripInfowithuserstatus=daoobject.showTripsWithUserStatus(team,x.getHiddenemail());
			 tripInfoforPlanning=daoobject.showTripsWhichHeCanPlan(x.getHiddenemail());
			System.out.println(tripInfo);
			 
			System.out.println("completely outside for");
			String val= y.registerTrip(info);
			
			System.out.println(val);
			
			DImplementation toStoreInvitedTeams=new DImplementation();
			toStoreInvitedTeams.storeteamsInvitedDetails(x.getTripId(), parts);
			
			 if (val.equals("ok")   ) {
				return "success";
		        } else {
		        	return "error";
		            //addActionError(getText("error.login")); 
		        }
			
			
			
		}

		@Override
		public Object getModel() {
			
			x = new TripDetails();
			return x;
		}

		@Override
		public void setSession(Map<String, Object> session) {
			this.session = session;
			
		}

	}



