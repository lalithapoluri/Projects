package userStatus;

import login.Info;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class UserComingStatus extends ActionSupport implements ModelDriven{

	private UserStatusInfo x;
	private String email;

	public String getEmail() {
		return email;
	}




	public void setEmail(String email) {
		this.email = email;
	}




	public String execute(){
		
		System.out.println("UserStatus"+x.getUserstatus());
		
		return "success";
	}
	
	
	
	
	@Override
	public Object getModel() {
		x = new UserStatusInfo();
		return x;
	}
	
	

}
