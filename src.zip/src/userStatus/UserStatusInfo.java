package userStatus;

public class UserStatusInfo {
	
	private String userstatus;
	public final String getUserstatus() {
		return userstatus;
	}

	public final void setUserstatus(String userstatus) {
		this.userstatus = userstatus;
	}

}
