package adminrights;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import mytravelarchitecture.RegisterInfo;

import org.apache.struts2.interceptor.SessionAware;

import serviceinfo.*;

import com.opensymphony.xwork2.ActionSupport;

public class UsersInformation extends ActionSupport implements SessionAware{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Map<String, Object> session;
	
	@Override
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
		this.session = session;
	}
	


	public String execute() throws SQLException {
	 
	 /* SInterface y=new SImplementation();
	  List<RegisterInfo> val =	y.showTrips(String email);
	  
	  for(int i = 0; i < val.size(); i++){
		  
		  session.put("val",(List<RegisterInfo>)val);
		  
    	    System.out.println(val.get(i));
    	}*/

	  return "success";
	}
}



















	
	//public String execute() throws FileNotFoundException, UnsupportedEncodingException{
		
		
		
	/*public static void main(String[] args)  {
		
	
		SI_Travel y=new SI_imp_Travel();
		
		// RegisterInfo info=new RegisterInfo();
       
       List<RegisterInfo> val =	y.showUser();
       //PrintWriter writer = new PrintWriter("file.txt", "UTF-8");
       
       for(int i = 0; i < val.size(); i++){
    	  // writer.println("The first line");
    	    System.out.println(val.get(i));
    	}*/
       
       //writer.close();
      
      // writer.println("The second line");
      
		//System.out.println(val.get);
		
		//return "success";
		
//writer.println("The first line");

/* List<RegisterInfo> attr =  (List<RegisterInfo>) ActionContext.getContext().get("val");
Object myProp = null;
((ActionContext) attr).put("val",myProp);*/
// Write to the session
	
/* // Read from the session
if (session.containsKey("val"))
  val=(List<RegisterInfo>)session.get("val");
*/

	
	
	
	
	

