package adminrights;

import mytravelarchitecture.RegisterInfo;

public interface ApproveInterface {
	
	public void NewUsers(RegisterInfo info);

}
