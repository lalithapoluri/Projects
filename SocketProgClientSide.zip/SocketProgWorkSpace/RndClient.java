CLIENT PROGRAM - WRITTEN IN "INTELLIJ IDEA" BY JETBRAINS

package homework6.client;
/**
 * Created by saipraneethyss on 10/25/2016.
 */

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Random; //imported to generate Random numbers
public class RndClient {
    public static void main(String[] args) throws Exception {
        Random numgen = new Random(); //creating "Random" class object.
        int numBytesRequested = numgen.nextInt(15); //Constructor call to create Rn values between 0-20
        int serverPort = 3939;
        byte[] sntMessage = new byte[1];
        sntMessage[0] = (byte)numBytesRequested; //Copying the #of bytes expected value
        System.out.println("number of bytes requested: "+sntMessage[0]);
        InetAddress server = InetAddress.getLocalHost(); //IP address of the SERVER Machine(Same Laptop).
        System.out.println("Server details: "+server);
        DatagramPacket D1 = new DatagramPacket(sntMessage,1,server,serverPort);//length = 1 since one byte of info is sent to server.
        DatagramSocket clientSocket = new DatagramSocket();
        clientSocket.send(D1);
        System.out.println("\nSending request to Sever");
        byte[] receivedMessage = new byte[numBytesRequested];
        DatagramPacket dReceived = new DatagramPacket(receivedMessage,numBytesRequested);
        try{
            clientSocket.setSoTimeout(5000);
            System.out.println("Receiving response from the server");
            clientSocket.receive(dReceived);   //System.out.println(dReceived.getLength()); to show the number of bytes received
            receivedMessage = dReceived.getData();
            System.out.println("The received data: ");
            for(int i=0;i<numBytesRequested;i++){System.out.println("the transmitted byte"+i+" is: "+receivedMessage[i]);}
        }
        catch (java.io.InterruptedIOException ex){
            System.out.println("Client Socket Timeout"+"\nException Message: "+ex.getMessage());
            System.exit(0);
        }
        clientSocket.close();//Socket Closed

    }

}

/*
OUTPUT 1:
    Server Side:
        Receiving request from client
        the client address is:/10.109.88.100
        the port number is:57532
        the # of bytes required: 12

        The sent data:
        the byte0 value is: 47
        the byte1 value is: -22
        the byte2 value is: -105
        the byte3 value is: -90
        the byte4 value is: 89
        the byte5 value is: -3
        the byte6 value is: -112
        the byte7 value is: 69
        the byte8 value is: -33
        the byte9 value is: 100
        the byte10 value is: -87
        the byte11 value is: 25
        Client Touch-based/n
        Receiving request from client

    Client Side:
        number of bytes requested: 12
        Server details: YS3P/10.109.88.100

        Sending request to Sever
        Receiving response from the server
        The received data:
        the transmitted byte0 is: 47
        the transmitted byte1 is: -22
        the transmitted byte2 is: -105
        the transmitted byte3 is: -90
        the transmitted byte4 is: 89
        the transmitted byte5 is: -3
        the transmitted byte6 is: -112
        the transmitted byte7 is: 69
        the transmitted byte8 is: -33
        the transmitted byte9 is: 100
        the transmitted byte10 is: -87
        the transmitted byte11 is: 25


OUTPUT 2: When the timeout occurs (Server Not running)

        number of bytes requested: 3
        Server details: YS3P/10.109.88.100

        Sending request to Sever
        Receiving response from the server
        Client Socket Timeout
        Exception Message: Receive timed out
*/
