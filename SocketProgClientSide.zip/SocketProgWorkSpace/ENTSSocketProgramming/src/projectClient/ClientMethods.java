package projectClient;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
//import java.util.Arrays;
import java.util.Scanner;

public class ClientMethods {

	private int measurementID = 0;
	private String[] dataValues = new String[200];
	private String newMsgwoCSUM = "";
	private List<String> serverValues = new ArrayList<String>();

	public List<String> getServerValues() {
		return serverValues;
	}

	public void setServerValues(List<String> serverValues) {
		this.serverValues = serverValues;
	}

	public String getNewMsgwoCSUM() {
		return newMsgwoCSUM;
	}

	public void setNewMsgwoCSUM(String newMsgwoCSUM) {
		this.newMsgwoCSUM = newMsgwoCSUM;
	}

	public String[] getDataValues() {
		return dataValues;
	}

	public void setDataValues(String[] dataValues) {
		this.dataValues = dataValues;
	}

	public int getMeasurementID() {
		return measurementID;
	}

	public void setMeasurementID(int measurementID) {
		this.measurementID = measurementID;
	}

	/*
	 * Get a random measurement ID from the data.txt file. values of the
	 * data.txt are stored in a string. values are taken randomly using the
	 * index
	 */
	public int getRandomMeasurementID() {

		String fileName = "data.txt";
		int i = 0;
		int randomVariable = (int) (Math.random() * 100);
		// System.out.println(randomVariable);
		try {
			FileReader fileReader = new FileReader(fileName);
			Scanner scanner = new Scanner(fileReader);
			while (scanner.hasNextLine()) {
				dataValues[i] = scanner.next();
				i++;
			}
			// System.out.println(Arrays.toString(dataValues));
			measurementID = Integer.parseInt(dataValues[randomVariable * 2]);
			System.out.println("Measurement Id randomly generated:  "
					+ measurementID);
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + fileName + "'");
		}
		return measurementID;

	}

	/*
	 * Calculates the checksum from message. Bytes of the Msg are taken
	 * converted to 16 bit values. The array is passed to getChecksum Method.
	 */
	public int getCheckSum(String message) {

		int len = 0;
		int checkSumValue = 0;
		int k = 0;
		int consecAdded16digit = 0;
		int[] array = {};
		// System.out.println(message);
		byte[] b1 = message.getBytes(Charset.forName("UTF-8"));
		if (b1.length % 2 == 0) {
			len = (b1.length) / 2;
		} else
			len = (b1.length + 1) / 2;
		array = new int[len];

		for (int i = 0; i < len; i++) {
			if (k > len) {
				consecAdded16digit = (256 * b1[k]) + 0;
			} else {
				consecAdded16digit = (256 * b1[k]) + b1[k + 1];
			}
			array[i] = consecAdded16digit;
			k = k + 2;
		}
		// System.out.println(Arrays.toString(array));
		checkSumValue = getChecksum(array);
		return checkSumValue;
	}

	/*
	 * Method: Gets the array. Index= s XOR array[i] s=(7919*index)MOD 65536.
	 */
	private int getChecksum(int[] array) {
		int s = 0;
		int index = 0;
		for (int i = 0; i < array.length; i++) {
			index = s ^ array[i];
			s = (7919 * index) % 65536;
		}
		System.out.println("Checksum: " + s);
		return s;
	}

	/*
	 * Method: Gets the msg from the Server. Extracts the checksum value sent
	 * from the response.
	 */
	public int getChecksumFromServer(String message) {
		int index = 0;
		String message1 = message.replaceAll("[^-?0-9.]+", " ");
		serverValues = Arrays.asList(message1.trim().split(" "));
		// System.out.println(clientValues);
		// System.out.println("Values from server"+serverValues);
		if (serverValues.size() > 3) {
			index = 4;
		} else
			index = 2;
		newMsgwoCSUM = message.replace(serverValues.get(index), "");
		// System.out.println("response without checksum"+newMsgwoCSUM);
		return Integer.parseInt(serverValues.get(index));
	}

	/*
	 * Method:checks if the checksum's are equal.
	 */
	public boolean isCheckSumEqual(int csFromServer, int csFromClient) {
		if (csFromServer == csFromClient)
			return true;
		else
			return false;

	}

	/*
	 * Method: Displays the error messages according to the code sent.
	 */
	public int displayErrorMsgs(String code) {
		Scanner obj = new Scanner(System.in);
		String userInput = "";
		if (code.equals("1")) {
			System.out
					.println("Error: integrity check failure. The request has one or more bit errors.");
			System.out.println("Do you want to resend ? Y/N ");
			userInput = obj.next();
			if (userInput.equalsIgnoreCase("N")) {
				System.out.println("Terminated");
				System.exit(0);
			}
		} else if (code.equals("3"))
			System.out
					.println("Error: non-existent measurement."
							+ " The measurement with the requested measurement ID does not exist.");
		else if (code.equals("2"))
			System.out
					.println("Error: malformed request. The syntax of the request message is not correct.");
		return 0;
	}
}
