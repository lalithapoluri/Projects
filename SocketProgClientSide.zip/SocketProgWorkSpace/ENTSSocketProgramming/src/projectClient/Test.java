package projectClient;

public class Test {

	public static void main(String[] args) {

		String str = "1234  3456";
		int x,y;

		String[] parts = str.split("  ", 2);
		String string1 = parts[0];
		String string2 = parts[1];
		 y = Integer.parseInt(string1);
		  
		 System.out.println(y);

		System.out.println(string1);  // prints name1
		System.out.println(string2);  // prints name2, name3, name4
		
	}

}
