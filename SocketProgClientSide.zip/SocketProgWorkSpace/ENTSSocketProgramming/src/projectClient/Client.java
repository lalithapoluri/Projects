package projectClient;

import java.io.*;
import java.net.*;
import java.util.Random;

public class Client {
	public static void main(String args[]) throws Exception

	{
		int timeout = 1000; // variable to store the timeOut value.
		int port = 7363;
		Random rand = new Random();
		int measureID = 0, checkSum = 0, iD = 0;
		boolean sendMsg = false; // This variable helps to send the same request
									// again.
		String message = "";
		int csOfServerMsg = 0; // checksum of Server Message
		int checkSumFrromServer = 0;
		DatagramSocket clientSocket = new DatagramSocket();
		InetAddress IPAddress = InetAddress.getByName("localhost"); // Gets the  IP add
		ClientMethods methodsObj = new ClientMethods(); // obj of the
														// ClientMethods class
		while (true) {

			iD = rand.nextInt(65536); // Random Id generated.
			measureID = methodsObj.getRandomMeasurementID();
			String sentence = "<request>\n" + "\t<id>" + iD + "</id>\n"
					+ "\t<measurement>" + measureID + "</measurement>\n"
					+ "</request>\n";
			checkSum = methodsObj.getCheckSum(sentence); // checksum of the
															// request message.
			message = sentence + checkSum; // Adding the checksum before sending
											// the message.
			System.out.println("Request to Server: \n" + message);
			byte[] sendData = new byte[message.length()];
			byte[] receiveData = new byte[1024];
			sendData = message.getBytes();

			DatagramPacket sendPacket = new DatagramPacket(sendData,
					sendData.length, IPAddress, port);
			do {
				clientSocket.send(sendPacket);
				sendMsg = false;
				DatagramPacket receivePacket = new DatagramPacket(receiveData,
						receiveData.length);
				try {
					clientSocket.setSoTimeout(timeout);
					clientSocket.receive(receivePacket);
					String msgFromServer = new String(receivePacket.getData(),
							0, receivePacket.getLength()); // Message received
															// from server.
					System.out.println("\nFROM SERVER:\n " + msgFromServer);
					checkSumFrromServer = methodsObj
							.getChecksumFromServer(msgFromServer); // checksum// of the response msg 		
					csOfServerMsg = methodsObj.getCheckSum(methodsObj
							.getNewMsgwoCSUM()); // Calculated checkSum of the
													// response to compare.
					methodsObj.displayErrorMsgs(methodsObj.getServerValues()
							.get(1));
					// System.out.println("New Response w/o CS"+methodsObj.getNewMsgwoCSUM());
					if (methodsObj.isCheckSumEqual(checkSumFrromServer,
							csOfServerMsg)) {
						timeout = 1000;
						System.out.println("Timer Reset to " + timeout);
					}

				} catch (SocketTimeoutException e) {
					System.out.println("Time Elapsed " + timeout);
					sendMsg = true;
					if (timeout < 5000) {
						timeout = timeout * 2;
						System.out.println("Time Out Increased to: " + timeout);

					} else {
						throw new Exception(
								"Communication Failure Receive timed out");
					}
				} catch (IOException e) {
					System.out.println("Client Socket Timeout"
							+ "\nException Message: " + e.getMessage());
				}
			} while (sendMsg);
		}
	}
}
