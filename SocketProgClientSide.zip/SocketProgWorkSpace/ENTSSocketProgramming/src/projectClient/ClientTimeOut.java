package projectClient;

import java.io.*;
import java.net.*;

public class ClientTimeOut {

	public static void main(String args[]) throws Exception
{
		int timeout = 1000;
		int port=8674;
		DatagramSocket clientSocket = new DatagramSocket();// Client Socket is created
		InetAddress IPAddress = InetAddress.getByName("localhost");	// Gets the IP Address
		byte[] sendData = new byte[1024];
		byte[] receiveData = new byte[1024];
		String sentence = "Hello";
		sendData = sentence.getBytes();// sends data		
		DatagramPacket sendPacket = new DatagramPacket(sendData,
				sendData.length, IPAddress, port);
		
		while (true) {
			clientSocket.send(sendPacket);
			tryReceiving(clientSocket, timeout, receiveData);
			/*
			 * DatagramPacket receivePacket = new DatagramPacket(receiveData,
			 * receiveData.length); tryReceiving(clientSocket, timeout,
			 * receivePacket);
			 */
		}
	}

	private static void tryReceiving(DatagramSocket clientSocket, int timeout,
			byte[] receiveData) throws Exception {
		DatagramPacket receivePacket = new DatagramPacket(receiveData,
				receiveData.length);
		try {
			clientSocket.setSoTimeout(timeout);
			clientSocket.receive(receivePacket);
			String modifiedSentence = new String(receivePacket.getData());
			System.out.println("FROM SERVER:\n" + modifiedSentence);
			timeout = 1000;
			System.out.println("Timer Reset to " + timeout);
			
		} catch (SocketTimeoutException e) {
			System.out.println("Time Elapsed " + timeout);
			if (timeout < 5000) {
				timeout = timeout * 2;
				System.out.println("Time Out Increased to: " + timeout);
				tryReceiving(clientSocket, timeout, receiveData);
			} else {
				throw new Exception("Communication Failure Receive timed out");
			}
		} catch (IOException e) {
			System.out.println("Client Socket Timeout"
					+ "\nException Message: " + e.getMessage());
		} 
	}

}
