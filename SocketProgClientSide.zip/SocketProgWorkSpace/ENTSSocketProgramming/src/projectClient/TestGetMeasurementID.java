package projectClient;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class TestGetMeasurementID {
	
	public static void main(String[] args) throws URISyntaxException {

		String fileName = "data.txt";
		String[] val=new String[200];
		int i=0,mID=0;
		String line = null;
		int randomVariable=(int) (Math.random()*100);
		System.out.println(randomVariable);
		try {
			FileReader fileReader = new FileReader(fileName);
			 Scanner scanner = new Scanner(fileReader);
			 while(scanner.hasNextLine()){
     	    	val[i]=scanner.next();
     	    	i++;
     	    }    
     	  System.out.println(Arrays.toString(val)); 
     	  mID=Integer.parseInt(val[randomVariable*2]);
     	  System.out.println("mID: "+mID);
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + fileName + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + fileName + "'");
			// Or we could just do this:
			// ex.printStackTrace();
		}

	}

}
